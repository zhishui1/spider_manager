"""
国家医保局爬虫核心模块
支持状态上报、Redis队列管理、URL去重和优雅停止
"""

import json
import os
import re
import signal
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set, Any
from urllib import parse
from bs4 import BeautifulSoup
import requests
from lxml import etree
import urllib3
import schedule
from threading import Thread

# 禁用SSL警告
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from .config import (
    COLUMN_CONFIGS,
    DATA_FILE,
    DETAIL_DELAY_MAX,
    DETAIL_DELAY_MIN,
    DOWNLOADABLE_EXTENSIONS,
    HEADERS,
    HTML_HEADERS,
    PAGE_LINK_EXTENSIONS,
    PROXIES,
    REQUEST_DELAY,
    REQUEST_DELAY_MAX,
    REQUEST_DELAY_MIN,
    REQUEST_TIMEOUT,
    RETRY_DELAY,
    RETRY_TIMES,
    SPIDER_NAME,
)
from ..utils import (
    BASE_DIR,
    generate_item_id,
    random_delay,
    human_like_delay,
    ensure_item_dir,
    save_content_to_file,
    download_file as utils_download_file,
)
from ...redis_manager import get_spider_redis_manager
from ...logger import get_spider_logger

URLS = {
    'list': 'https://www.nhsa.gov.cn/module/web/jpage/dataproxy.jsp',
    'detail': 'https://www.nhsa.gov.cn/art/{article_id}.html',
}


class ErrorManager:
    """错误管理器 - 负责错误记录和统计"""

    def __init__(self, spider_name: str = SPIDER_NAME):
        self.spider_name = spider_name
        self.rm = get_spider_redis_manager(spider_name)
        self.logger = get_spider_logger(spider_name)
        self._error_log_file = Path(f'{spider_name}_errors.log')

    def record_error(self, error_type: str, url: str, message: str):
        """记录错误"""
        timestamp = datetime.now().isoformat()
        error_entry = {
            'timestamp': timestamp,
            'type': error_type,
            'url': url,
            'message': message
        }

        try:
            self.logger.error(message, error_type=error_type, url=url)

            with open(self._error_log_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(error_entry, ensure_ascii=False) + '\n')
        except Exception as e:
            print(f"[错误] 记录错误失败: {e}")

    def get_error_count(self) -> int:
        """获取错误数量"""
        return self.rm.get_error_count()

    def get_recent_errors(self, limit: int = 10) -> List[Dict]:
        """获取最近错误"""
        return self.rm.get_recent_errors(limit)


class NHSACrawler:
    """国家医保局爬虫"""

    def __init__(self):
        self.rm = get_spider_redis_manager(SPIDER_NAME)
        self.logger = get_spider_logger(SPIDER_NAME)
        self.url_manager = self.rm
        self.error_manager = ErrorManager()
        self.is_running = False
        self.should_stop = False
        self.should_pause = False
        self.is_scheduler_running = False
        self.status = 'idle'
        self.current_date_dir = None

        self._setup_signal_handlers()

    def _setup_signal_handlers(self):
        """设置信号处理器"""
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT, self._signal_handler)

    def _signal_handler(self, signum, frame):
        """信号处理"""
        print(f"\n[信号] 收到信号 {signum}，准备停止爬虫...")
        self.should_stop = True

    def _check_pause(self):
        """检查暂停状态"""
        while self.should_pause or self.rm.is_paused():
            if self.should_stop:
                break
            time.sleep(1)
            if self.should_stop:
                break

    def _sanitize_filename(self, filename: str) -> str:
        """清理文件名"""
        if not filename:
            return 'untitled'

        invalid_chars = r'<>:"/\|?*'
        for char in invalid_chars:
            filename = filename.replace(char, '_')

        filename = re.sub(r'[\x00-\x1f]', '', filename)
        filename = filename.strip('. ')

        reserved_names = ['CON', 'PRN', 'AUX', 'NUL', 'COM1', 'COM2', 'COM3',
                         'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9',
                         'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6',
                         'LPT7', 'LPT8', 'LPT9']
        name_without_ext = filename.split('.')[0].upper()
        if name_without_ext in reserved_names:
            filename = f'_{filename}'

        if len(filename) > 255:
            filename = filename[:255]

        return filename or 'untitled'

    def _html_decode(self, resp: requests.Response) -> str:
        """解码HTML响应"""
        html_text = resp.text
        charset = re.findall(r'charset="(.*?)"', html_text)
        if charset:
            charset = charset[0]
            html = resp.content.decode(charset, errors='ignore')
        elif resp.encoding == "ISO-8859-1":
            resp.encoding = None
            html = resp.text
        else:
            html = resp.text
        return html

    def _use_xpath(self, html: str):
        """使用XPath解析HTML"""
        doc = etree.HTML(html)
        return doc

    def _request_get(self, url: str, session: requests.Session = None,
                     proxies: dict = None, retry: int = RETRY_TIMES,
                     headers = HEADERS, cookies = None) -> Optional[requests.Response]:
        """发送GET请求"""
        resp = None
        for i in range(1, retry + 1):
            try:
                if i == retry:
                    self.error_manager.record_error('retry_exhausted', url, f'重试{i}次后失败')
                if not session:
                    resp = requests.get(url, headers=headers, proxies=proxies,
                                       timeout=REQUEST_TIMEOUT, verify=False, cookies=cookies)
                else:
                    resp = session.get(url, headers=headers, timeout=REQUEST_TIMEOUT,
                                      verify=False, cookies=cookies)
                if resp.status_code == 200:
                    return resp
                elif resp.status_code == 404:
                    self.logger.warning(f'页面不存在: {url}', error_type='404', url=url)
                    break
                else:
                    self.logger.warning(f'状态码 {resp.status_code}，重试第{i}次: {url}', error_type='request_error', url=url)
                    time.sleep(RETRY_DELAY)
            except Exception as e:
                self.logger.error(f'请求错误: {e}，重试第{i}次: {url}', error_type='request_error', url=url)
                time.sleep(RETRY_DELAY)
        return resp

    def _request_post(self, url: str, data: dict, params: dict = None,
                      retry: int = RETRY_TIMES, headers = HTML_HEADERS) -> Optional[requests.Response]:
        """发送POST请求"""
        resp = None
        for i in range(1, retry + 1):
            try:
                if i == retry:
                    self.error_manager.record_error('retry_exhausted', url, f'重试{i}次后失败')
                resp = requests.post(url, data=data, params=params, headers=headers,
                                    proxies=PROXIES, timeout=REQUEST_TIMEOUT, verify=False)
                if resp.status_code == 200:
                    return resp
                else:
                    self.logger.warning(f'POST状态码 {resp.status_code}，重试第{i}次: {url}', error_type='request_error', url=url)
                    time.sleep(RETRY_DELAY)
            except Exception as e:
                self.logger.error(f'POST请求错误: {e}，重试第{i}次: {url}', error_type='request_error', url=url)
                time.sleep(RETRY_DELAY)
        return resp

    def _parse_response(self, resp: requests.Response):
        """解析响应内容"""
        try:
            content = resp.text
            content = re.sub(r'<\?xml[^>]*\?>', '', content)
            content = content.strip()
            if not content:
                return None
            return etree.HTML(content)
        except Exception as e:
            self.logger.error(f'解析响应失败: {e}')
            return None

    def _extract_data_from_html(self, content: str) -> List[Dict]:
        """从HTML提取数据"""
        record_pattern = r'<record><!\[CDATA\[(.*?)\]\]></record>'
        records = re.findall(record_pattern, content, re.DOTALL)

        data_list = []
        for record in records:
            soup = BeautifulSoup(record, 'html.parser')
            spans = soup.find_all('span')

            if len(spans) >= 4:
                index = spans[0].get_text(strip=True)
                a_tag = spans[1].find('a')
                title = a_tag.get_text(strip=True) if a_tag else spans[1].get_text(strip=True)
                url = a_tag.get('href', '') if a_tag else ''
                url = parse.urljoin('https://www.nhsa.gov.cn/', url)
                document_number = spans[2].get_text(strip=True)
                publish_date = spans[3].get_text(strip=True)

                data_list.append({
                    '索引': index,
                    '标题': title,
                    '发文字号': document_number,
                    '发布日期': publish_date,
                    'URL': url
                })

        return data_list

    def _process_item(self, item: Dict, category: str, category_count: Dict) -> bool:
        """处理单个条目"""
        url = item['URL']

        if self.url_manager.is_duplicate(url):
            self.logger.info(f'链接已存在，跳过: {url}')
            return False

        self._check_pause()
        if self.should_stop:
            return False

        try:
            item_id = generate_item_id()

            resp = self._request_get(url, headers=HTML_HEADERS)
            if not resp or resp.status_code != 200:
                self.logger.info(f'无法获取页面: {url}', error_type='request_failed', url=url)
                return None

            html = self._html_decode(resp)
            doc = self._use_xpath(html)

            title = doc.xpath('//span[@class="mu-sp-2"]/text()')
            title = title[0] if title else item['标题']

            content_elements = doc.xpath('//div[@id="zoom"]//text()')
            content = ''.join(content_elements).strip()

            hrefs = doc.xpath('//div[@id="zoom"]//a/@href')
            has_downloadable = False
            for href in hrefs:
                if not href or not isinstance(href, str):
                    continue
                href = href.strip().lower()
                if not href:
                    continue
                is_downloadable = any(ext in href for ext in DOWNLOADABLE_EXTENSIONS)
                is_page_link = any(ext in href for ext in PAGE_LINK_EXTENSIONS)
                if is_downloadable and not is_page_link:
                    has_downloadable = True
                    break

            if not content and not has_downloadable:
                self.logger.info(f'无内容且无附件，已跳过: {title}', error_type='no_content', url=url)
                return None

            item_dir = ensure_item_dir(SPIDER_NAME, item_id)
            if content:
                save_content_to_file(content, item_dir, f'{item_id}_1.txt')

            file_index = 2
            for href in hrefs:
                if not href or not isinstance(href, str):
                    continue
                href = href.strip()
                if not href:
                    continue
                href_lower = href.lower()
                is_downloadable = any(ext in href_lower for ext in DOWNLOADABLE_EXTENSIONS)
                is_page_link = any(ext in href_lower for ext in PAGE_LINK_EXTENSIONS)
                if not is_downloadable or is_page_link:
                    continue
                dl_url = parse.urljoin('https://www.nhsa.gov.cn/', href)
                saved_path = utils_download_file(dl_url, item_dir, f'{item_id}_{file_index}')
                if saved_path:
                    self.logger.info(f'附件下载成功: {saved_path}')
                    file_index += 1
                time.sleep(0.5)

            data = {
                'item_id': item_id,
                'title': title,
                'publish_date': item['发布日期'],
                'url': url,
                'data': {
                    'category': category,
                    'index': item['索引'],
                    'document_number': item['发文字号'],
                    'crawled_at': datetime.now().isoformat()
                }
            }

            with open(DATA_FILE, 'a', encoding='utf-8') as f:
                f.write(json.dumps(data, ensure_ascii=False) + '\n')

            category_count[category] = category_count.get(category, 0) + 1
            self.logger.info(f'处理成功: {title}')
            return True

        except Exception as e:
            self.logger.error(f'处理失败: {e}', error_type='process_error', url=url)
            return None

    def _crawl_column(self, column_id: int, category: str, end_records: int) -> Dict[str, int]:
        """爬取单个栏目"""
        category_count = {}
        startrecord = 0
        endrecord = 0
        perpage = 15
        total_crawled = 0
        total_errors = self.error_manager.get_error_count()

        while endrecord < end_records:
            if self.should_stop:
                break

            startrecord = endrecord
            endrecord = min(endrecord + perpage, end_records)

            self._check_pause()
            if self.should_stop:
                break

            params = {
                'startrecord': str(startrecord + 1),
                'endrecord': str(endrecord),
                'perpage': str(perpage),
            }

            data = {
                'col': '1',
                'appid': '1',
                'webid': '1',
                'path': '/',
                'columnid': str(column_id),
                'sourceContentType': '1',
                'unitid': '2464',
                'webname': '国家医疗保障局',
                'permissiontype': '0',
            }

            try:
                response = requests.post(
                    'https://www.nhsa.gov.cn/module/web/jpage/dataproxy.jsp',
                    params=params,
                    cookies={},
                    headers=HEADERS,
                    data=data,
                    timeout=REQUEST_TIMEOUT
                )

                if response.status_code != 200:
                    self.logger.error(f'API返回状态码{response.status_code}', error_type='api_error', column_id=str(column_id))
                    continue

                items = self._extract_data_from_html(response.text)
                self.logger.info(f'栏目: {category} - 从 {startrecord + 1} 到 {endrecord}，共 {len(items)} 条')

                for item in items:
                    if self._process_item(item, category, category_count):
                        total_crawled += 1

                    # current_errors = self.error_manager.get_error_count()
                    # self.status_manager.update_progress(
                    #     total_crawled,
                    #     end_records,
                    #     category,
                    #     current_errors - total_errors
                    # )

                    time.sleep(REQUEST_DELAY)

                    if self.should_stop:
                        break

            except Exception as e:
                self.logger.error(f'栏目 {column_id} 爬取失败: {e}', error_type='column_error', column_id=str(column_id))

        return category_count

    def _is_all_pagination_complete(self) -> bool:
        """检查所有栏目的翻页是否都已完成"""
        for column_id in COLUMN_CONFIGS.keys():
            if not self.rm.is_pagination_complete(column_id):
                return False
        return True

    def _scheduled_crawl_links(self):
        """定时爬取链接：从第一页开始无限翻页，与visited_urls去重"""
        self.logger.info('开始定时爬取链接...')
        self.rm.set_status('running', {'started_at': datetime.now().isoformat()})

        self.current_date_dir = None

        total_new_links = 0
        for column_id, config in COLUMN_CONFIGS.items():
            if self.should_stop:
                break

            category = config['name']
            self.logger.info(f'开始收集栏目: {category}')
            self.rm.set_status('running', {
                'current_category': category
            })

            startrecord = 0
            perpage = 15
            consecutive_duplicates = 0
            page_num = 1
            stop_pagination = False

            while not self.should_stop and not stop_pagination:
                endrecord = min(startrecord + perpage, startrecord + perpage)

                params = {
                    'startrecord': str(startrecord + 1),
                    'endrecord': str(endrecord),
                    'perpage': str(perpage),
                }

                data = {
                    'col': '1',
                    'appid': '1',
                    'webid': '1',
                    'path': '/',
                    'columnid': str(column_id),
                    'sourceContentType': '1',
                    'unitid': '2464',
                    'webname': '国家医疗保障局',
                    'columnid': str(column_id),
                }

                try:
                    resp = self._request_post(URLS['list'], data, params)
                    if not resp:
                        break

                    tree = self._parse_response(resp)
                    if not tree:
                        break

                    links = tree.xpath('//item/list/pageUrl/text()')
                    titles = tree.xpath('//item/list/Title/text()')
                    indexes = tree.xpath('//item/list/Index/text()')
                    document_numbers = tree.xpath('//item/list/text_' + str(column_id) + '/text()')
                    publish_dates = tree.xpath('//item/list/date/text()')

                    if not links:
                        self.logger.info(f'栏目 {category} 第{page_num}页无数据，继续检查后续页面')
                        startrecord = endrecord
                        page_num += 1
                        time.sleep(REQUEST_DELAY)
                        continue

                    new_links_count = 0
                    for i, link in enumerate(links):
                        if self.should_stop:
                            break

                        url = link.strip()
                        if not url:
                            continue

                        title = titles[i].strip() if i < len(titles) else ''
                        index = indexes[i].strip() if i < len(indexes) else ''
                        document_number = document_numbers[i].strip() if i < len(document_numbers) else ''
                        publish_date = publish_dates[i].strip() if i < len(publish_dates) else ''

                        if self.url_manager.is_duplicate(url):
                            consecutive_duplicates += 1
                            if consecutive_duplicates >= 100:
                                self.logger.info(f'栏目 {category} 连续{consecutive_duplicates}个重复，停止翻页')
                                stop_pagination = True
                                break
                            continue

                        consecutive_duplicates = 0
                        link_data = {
                            'url': url,
                            'category': category,
                            'title': title,
                            'index': index,
                            'document_number': document_number,
                            'publish_date': publish_date,
                        }
                        self.rm.push_to_links_queue(link_data)
                        self.rm.mark_url_visited(url)
                        new_links_count += 1
                        total_new_links += 1

                    self.logger.info(f'栏目 {category} 第{page_num}页: 新增 {new_links_count} 个链接')
                    startrecord = endrecord
                    page_num += 1

                    time.sleep(REQUEST_DELAY)

                except Exception as e:
                    self.logger.error(f'栏目 {category} 第{page_num}页爬取失败: {e}')
                    break

            self.logger.info(f'栏目 {category} 链接收集完成，新增 {total_new_links} 个链接')

        self.rm.set_status('running', {
            'new_links': total_new_links
        })
        self.logger.info(f'定时链接爬取完成，新增 {total_new_links} 个链接')

        if self.rm.has_pending_links():
            self.logger.info('发现待爬取的详情链接，开始爬取详情...')
            self._crawl_details_phase()

        self.rm.set_status('stopped', {
            'stopped_at': datetime.now().isoformat(),
            'reason': 'scheduled_completed',
            'links_collected': self.rm.get_visited_count(),
            'details_crawled': self.rm.get_crawled_count()
        })
        self.logger.info('定时爬取全部完成')

    def _start_scheduler(self):
        """启动定时调度器（每天上午8点执行）"""
        if self.is_scheduler_running:
            self.logger.info('调度器已在运行中，跳过启动')
            return

        def job():
            if self._is_all_pagination_complete() and self.rm.get_links_queue_size() == 0:
                self.logger.info('所有栏目已完成且队列为空，进入每日定时爬取模式')
                self._scheduled_crawl_links()
            elif self.rm.get_links_queue_size() > 0:
                self.logger.info('发现待爬取链接，跳过定时爬取，开始爬取详情...')
                self._crawl_details_phase()
            else:
                self.logger.info('还有未完成的翻页，跳过定时爬取')

        self.is_scheduler_running = True
        schedule.every().day.at('08:00').do(job)
        self.logger.info('定时调度器已启动，每天上午8点执行')

        while not self.should_stop and self.is_scheduler_running:
            schedule.run_pending()
            time.sleep(60)

        self.is_scheduler_running = False
        self.logger.info('定时调度器已停止')

    def _stop_scheduler(self):
        """停止定时调度器"""
        self.is_scheduler_running = False
        self.logger.info('定时调度器已停止')

    def run(self):
        """运行爬虫（两阶段爬取流程）"""
        if self.is_running:
            print('[警告] 爬虫已在运行中')
            return False

        self.is_running = True
        self.should_stop = False
        self.should_pause = False

        try:
            self.rm.set_status('running', {'started_at': datetime.now().isoformat()})
            self.logger.info(f'{SPIDER_NAME} 爬虫启动')

            if self._is_all_pagination_complete() and self.rm.get_links_queue_size() == 0:
                self.logger.info('所有栏目翻页已完成且无待爬取链接，进入每日定时爬取模式')
                self._start_scheduler()
                return True

            if self.rm.has_incomplete_pagination(COLUMN_CONFIGS):
                self.logger.info('发现未完成的翻页，开始收集链接...')
                self._collect_links_phase()

            if self.should_stop:
                self.logger.info('用户停止爬虫')
                return True

            if self.rm.has_pending_links():
                self.logger.info(f'发现待爬取的详情链接，开始爬取详情...')
                self._crawl_details_phase()
            else:
                self.logger.info('没有待爬取的详情链接')

            if not self.should_stop:
                self.rm.set_status('stopped', {
                    'stopped_at': datetime.now().isoformat(),
                    'reason': 'completed',
                    'links_collected': self.rm.get_visited_count(),
                    'details_crawled': self.rm.get_crawled_count()
                })
                self.logger.info('全部爬取完成')

                if self._is_all_pagination_complete() and self.rm.get_links_queue_size() == 0:
                    self.logger.info('所有栏目已完成且队列为空，自动启动定时调度器...')
                    self._start_scheduler()
                else:
                    self.logger.info('爬取完成，等待手动启动')
            return True

        except Exception as e:
            error_msg = str(e)
            self.logger.error(f'严重错误: {error_msg}', error_type='fatal_error', url='crawler')
            self.rm.set_status('error', {'error': error_msg})
            return False

        finally:
            self.is_running = False
            self._stop_scheduler()
            if self.should_stop:
                self.rm.set_status('stopped', {
                    'stopped_at': datetime.now().isoformat(),
                    'reason': 'user_stopped',
                    'links_collected': self.rm.get_visited_count(),
                    'details_crawled': self.rm.get_crawled_count()
                })
                self.logger.info('爬虫已停止')

    def _collect_links_phase(self):
        """阶段1：收集详情页链接"""
        for column_id, config in COLUMN_CONFIGS.items():
            if self.should_stop:
                break

            if self.rm.is_pagination_complete(column_id):
                self.logger.info(f'栏目 {config["name"]} 已完成，跳过')
                continue

            category = config['name']
            end_records = config['end_records']

            self.logger.info(f'开始收集栏目: {category}')
            self.rm.set_status('running', {
                'current_category': category,
                'progress': f'收集 {category} 的链接'
            })

            self._collect_column_links(column_id, category, end_records)

            self.rm.set_pagination_complete(column_id, True)
            self.logger.info(f'栏目 {category} 链接收集完成')

    def _collect_column_links(self, column_id: int, category: str, end_records: int):
        """收集单个栏目的详情页链接"""
        startrecord = self.rm.get_last_pagination_page(column_id)
        endrecord = startrecord
        perpage = 15

        self.logger.info(f'栏目 {category} 从第 {startrecord // perpage + 1} 页开始')

        while endrecord < end_records:
            if self.should_stop:
                break

            self._check_pause()
            if self.should_stop:
                break

            startrecord = endrecord
            endrecord = min(endrecord + perpage, end_records)
            links_count = 0
            items_count = 0

            params = {
                'startrecord': str(startrecord + 1),
                'endrecord': str(endrecord),
                'perpage': str(perpage),
            }

            data = {
                'col': '1',
                'appid': '1',
                'webid': '1',
                'path': '/',
                'columnid': str(column_id),
                'sourceContentType': '1',
                'unitid': '2464',
                'webname': '国家医疗保障局',
                'permissiontype': '0',
            }

            try:
                response = requests.post(
                    'https://www.nhsa.gov.cn/module/web/jpage/dataproxy.jsp',
                    params=params,
                    cookies={},
                    headers=HEADERS,
                    data=data,
                    timeout=REQUEST_TIMEOUT
                )

                if response.status_code != 200:
                    self.error_manager.record_error('api_error', str(column_id),
                                                   f'API返回状态码{response.status_code}')
                else:
                    items = self._extract_data_from_html(response.text)
                    items_count = len(items)
                    links_count = 0

                    for item in items:
                        if self.should_stop:
                            break

                        self._check_pause()
                        if self.should_stop:
                            break

                        url = item['URL']
                        if self.rm.is_url_visited(url):
                            self.logger.info(f'链接已存在，跳过: {url}')
                            continue

                        link_data = {
                            'url': url,
                            'title': item.get('标题', ''),
                            'category': category,
                            'index': item.get('索引', ''),
                            'document_number': item.get('发文字号', ''),
                            'publish_date': item.get('发布日期', ''),
                            'collected_at': datetime.now().isoformat()
                        }

                        self.rm.push_to_links_queue(link_data)
                        self.rm.mark_url_visited(url)
                        links_count += 1

            except Exception as e:
                self.logger.error(f'栏目 {column_id} 翻页失败: {e}', error_type='column_error', column_id=str(column_id))

            # 无论成功失败，都保存翻页进度
            self.rm.set_last_pagination_page(column_id, endrecord)

            if self.should_stop:
                break

            random_delay(REQUEST_DELAY_MIN, REQUEST_DELAY_MAX)

            current_page = startrecord // perpage + 1
            total_pages = (end_records + perpage - 1) // perpage
            self.logger.link_collection(category, current_page, total_pages, items_count, links_count)

    def _crawl_details_phase(self):
        """阶段2：从队列爬取详情页"""
        total_to_crawl = self.rm.get_links_queue_size() + self.rm.get_details_crawled()
        crawled_count = self.rm.get_details_crawled()

        self.logger.info(f'待爬取 {self.rm.get_links_queue_size()} 条详情，总计 {total_to_crawl} 条')

        consecutive_errors = 0

        while self.rm.has_pending_links() and not self.should_stop:
            self._check_pause()
            if self.should_stop:
                break

            link_data = self.rm.pop_from_links_queue()
            if not link_data:
                break

            url = link_data.get('url')
            if self.rm.is_url_crawled(url):
                self.logger.info(f'已爬取过，跳过: {url}')
                continue

            success = self._crawl_detail_page(link_data)

            if success is True:
                self.rm.mark_url_crawled(url)
                crawled_count = self.rm.increment_details_crawled()
                self.logger.info(f'详情爬取进度: {crawled_count}/{total_to_crawl}')
                consecutive_errors = 0
            elif success is None:
                crawled_count = self.rm.increment_details_crawled()
                self.logger.info(f'详情爬取进度（无内容跳过）: {crawled_count}/{total_to_crawl}')
                consecutive_errors = 0
            else:
                consecutive_errors += 1
                if consecutive_errors >= 100:
                    self.logger.error(f'连续{consecutive_errors}次爬取失败，停止爬虫', error_type='too_many_errors', url=url)
                    self.rm.set_status('stopped', {
                        'stopped_at': datetime.now().isoformat(),
                        'reason': 'too_many_errors',
                        'error_url': url,
                        'links_collected': self.rm.get_visited_count(),
                        'details_crawled': self.rm.get_crawled_count()
                    })
                    break
                self.logger.error(f'爬取失败，将URL放回队列重试: {url}', error_type='detail_failed', url=url)
                self.rm.push_to_links_queue(link_data)
                self.logger.info(f'爬取继续，剩余 {self.rm.get_links_queue_size()} 条待爬取')

    def _crawl_detail_page(self, link_data: Dict[str, Any]):
        """爬取单个详情页"""
        url = link_data.get('url')
        category = link_data.get('category', '未知')

        random_delay(DETAIL_DELAY_MIN, DETAIL_DELAY_MAX)

        try:
            item_id = generate_item_id()

            resp = self._request_get(url, headers=HTML_HEADERS)
            if not resp or resp.status_code != 200:
                self.logger.info(f'无法获取页面: {url}', error_type='request_failed', url=url)
                return None

            html = self._html_decode(resp)
            doc = self._use_xpath(html)

            title = doc.xpath('//span[@class="mu-sp-2"]/text()')
            title = title[0] if title else link_data.get('title', '无标题')

            content_elements = doc.xpath('//div[@id="zoom"]//text()')
            content = ''.join(content_elements).strip()

            hrefs = doc.xpath('//div[@id="zoom"]//a/@href')
            has_downloadable = False
            for href in hrefs:
                if not href or not isinstance(href, str):
                    continue
                href = href.strip().lower()
                if not href:
                    continue
                is_downloadable = any(ext in href for ext in DOWNLOADABLE_EXTENSIONS)
                is_page_link = any(ext in href for ext in PAGE_LINK_EXTENSIONS)
                if is_downloadable and not is_page_link:
                    has_downloadable = True
                    break

            if not content and not has_downloadable:
                self.logger.info(f'无内容且无附件，已跳过: {title}', error_type='no_content', url=url)
                return None

            item_dir = ensure_item_dir(SPIDER_NAME, item_id)
            if content:
                save_content_to_file(content, item_dir, f'{item_id}_1.txt')

            file_index = 2
            for href in hrefs:
                if file_index > 20:
                    break
                if not href or not isinstance(href, str):
                    continue
                href = href.strip()
                if not href:
                    continue
                href_lower = href.lower()
                is_downloadable = any(ext in href_lower for ext in DOWNLOADABLE_EXTENSIONS)
                is_page_link = any(ext in href_lower for ext in PAGE_LINK_EXTENSIONS)
                if not is_downloadable or is_page_link:
                    continue
                dl_url = parse.urljoin('https://www.nhsa.gov.cn/', href)
                saved_path = utils_download_file(dl_url, item_dir, f'{item_id}_{file_index}')
                if saved_path:
                    self.logger.info(f'附件下载成功: {saved_path}')
                    file_index += 1
                time.sleep(0.5)

            data = {
                'item_id': item_id,
                'title': title,
                'publish_date': link_data.get('publish_date', ''),
                'url': url,
                'data': {
                    'category': category,
                    'index': link_data.get('index', ''),
                    'document_number': link_data.get('document_number', ''),
                    'crawled_at': datetime.now().isoformat()
                }
            }

            with open(DATA_FILE, 'a', encoding='utf-8') as f:
                f.write(json.dumps(data, ensure_ascii=False) + '\n')

            crawled_count = self.rm.get_crawled_count()
            total_count = crawled_count + self.rm.get_links_queue_size() + 1
            self.logger.detail_crawl(title, url, crawled_count, total_count)
            return True

        except Exception as e:
            self.logger.error(f'处理失败: {e}', error_type='process_error', url=url)
            return None

    def stop(self):
        """停止爬虫"""
        self.should_stop = True
        self.status_manager.set_status('stopping', {})

    def pause(self):
        """暂停爬虫"""
        self.should_pause = True
        self.rm.set_paused(True)
        self.rm.set_status('paused', {})

    def resume(self):
        """恢复爬虫"""
        self.should_pause = False
        self.rm.set_paused(False)
        self.rm.set_status('running', {'resumed_at': datetime.now().isoformat()})

    def get_status(self) -> Dict[str, Any]:
        """获取爬虫状态"""
        base_status = self.rm.get_status()
        progress = base_status.get('details', {})

        return {
            'status': base_status.get('status', 'unknown'),
            'running': self.is_running,
            'paused': self.should_pause or base_status.get('details', {}).get('paused') == '1',
            'progress': progress,
            'error_count': self.error_manager.get_error_count(),
            'source': base_status.get('source', 'unknown')
        }


def main():
    """主入口"""
    crawler = NHSACrawler()
    success = crawler.run()
    sys.exit(0 if success else 1)


if __name__ == '__main__':
    main()
