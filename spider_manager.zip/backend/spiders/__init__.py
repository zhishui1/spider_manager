"""
The __init__.py file makes spiders a Python package.
"""
