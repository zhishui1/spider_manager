import json
import os
import time
from urllib import parse
from bs4 import BeautifulSoup
import requests
from lxml import etree
import urllib3

os.makedirs('./wjw_htmls', exist_ok=True)
os.makedirs('./wjw_files', exist_ok=True)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36",
}

def request_get(url: str, retry: int = 3, headers=headers, proxies=None):
    """封装 requests.get()，支持重试"""
    resp = None
    for i in range(1, retry + 1):
        try:
            resp = requests.get(url, headers=headers, timeout=10, verify=False, proxies=proxies)
            if resp.status_code == 200:
                return resp
            elif resp.status_code == 404:
                print(f'404 not retry: {url}')
                break
            else:
                print(f'Error - retry {i}/{retry} - {url} - status: {resp.status_code}')
                time.sleep(5)
                continue
        except Exception as e:
            print(f'Error - retry {i}/{retry} - {url} - error: {e}')
            time.sleep(5)
            continue
    return resp

def html_decode(resp: requests.Response):
    """解码响应内容"""
    html_text = resp.text
    charset = re.findall(r'charset="(.*?)"', html_text)
    if charset:
        charset = charset[0]
        html = resp.content.decode(charset, errors='ignore')
    elif resp.encoding == "ISO-8859-1":
        resp.encoding = None
        html = resp.text
    else:
        html = resp.text
    return html

def sanitize_filename(filename: str, replacement: str = '_') -> str:
    """删除字符串中不符合Windows文件命名规则的字符"""
    if not filename:
        return 'untitled'
    
    invalid_chars = r'<>:"/\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, replacement)
    
    filename = re.sub(r'[\x00-\x1f]', '', filename)
    filename = filename.strip('. ')
    
    reserved_names = [
        'CON', 'PRN', 'AUX', 'NUL',
        'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9',
        'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'
    ]
    
    name_without_ext = filename.split('.')[0].upper()
    if name_without_ext in reserved_names:
        filename = f'{replacement}{filename}'
    
    if len(filename) > 255:
        filename = filename[:255]
    
    if not filename:
        filename = 'untitled'
    
    return filename

def extract_data_from_page(content, url):
    """从页面提取数据"""
    soup = BeautifulSoup(content, 'html.parser')
    
    title_elem = soup.find('title')
    title = title_elem.get_text(strip=True) if title_elem else ''
    
    date_elem = soup.find('span', class_='time') or soup.find('span', class_='date')
    publish_date = date_elem.get_text(strip=True) if date_elem else ''
    
    content_elem = soup.find('div', class_='content') or soup.find('div', class_='TRS_Editor')
    page_content = content_elem.get_text(strip=True) if content_elem else ''
    
    file_links = []
    for link in soup.find_all('a'):
        href = link.get('href', '')
        link_text = link.get_text(strip=True)
        if href and ('doc' in href or 'pdf' in href or 'xls' in href or 'zip' in href):
            file_links.append({
                'url': parse.urljoin(url, href),
                'name': link_text or href.split('/')[-1]
            })
    
    return {
        'title': title,
        'publish_date': publish_date,
        'content': page_content,
        'file_links': file_links,
        'url': url
    }

def crawl_wjw_news(max_pages: int = 10):
    """爬取卫健委网站新闻"""
    base_url = "http://www.nhc.gov.cn/wjw/"
    articles = []
    
    for page in range(1, max_pages + 1):
        try:
            if page == 1:
                url = f"{base_url}zxft_79/index.html"
            else:
                url = f"{base_url}zxft_79/index_{page}.html"
            
            print(f'Crawling page {page}: {url}')
            resp = request_get(url)
            
            if not resp or resp.status_code != 200:
                continue
            
            html = html_decode(resp)
            doc = etree.HTML(html)
            
            article_links = doc.xpath('//div[@class="list"]//li/a/@href')
            
            for link in article_links[:10]:
                article_url = parse.urljoin(base_url, link)
                print(f'  Crawling article: {article_url}')
                
                article_resp = request_get(article_url)
                if article_resp and article_resp.status_code == 200:
                    article_html = html_decode(article_resp)
                    data = extract_data_from_page(article_html, article_url)
                    
                    if data['title']:
                        articles.append(data)
                        
                        with open('./wjw_data.json', 'a', encoding='utf-8') as f:
                            json.dump(data, f, ensure_ascii=False)
                            f.write('\n')
                
                time.sleep(2)
            
            time.sleep(3)
            
        except Exception as e:
            print(f'Error crawling page {page}: {e}')
            continue
    
    print(f'Crawl completed. Total articles: {len(articles)}')
    return articles

def main():
    print("Starting WJW crawler...")
    articles = crawl_wjw_news(max_pages=5)
    print(f"Successfully crawled {len(articles)} articles")

if __name__ == '__main__':
    main()
