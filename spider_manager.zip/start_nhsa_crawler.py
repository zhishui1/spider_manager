"""
爬虫启动器 - 设置Python路径并启动爬虫
"""
import sys
from pathlib import Path

# 添加backend到Python路径
backend_path = Path(__file__).parent / 'backend'
sys.path.insert(0, str(backend_path))

# 导入并运行爬虫
from spiders.crawlers.nhsa.crawler import main

if __name__ == '__main__':
    main()
